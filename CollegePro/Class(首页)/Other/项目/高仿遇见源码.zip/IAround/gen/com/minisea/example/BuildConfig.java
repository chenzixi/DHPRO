/** Automatically generated file. DO NOT MODIFY */
package com.minisea.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}